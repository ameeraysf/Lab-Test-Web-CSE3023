//Author : Ameera S76240

package com.Model;
//MODEL LAYER
//MAPS DIRECTLY TO THE DATABASE SQL

//Declaring all private variables
public class SessionBean {
    protected int session_id; //FROM DATABASE //ONLY ACCESSIBLE WITHIN THE PACKAGE
    protected String student_name;
    protected String branch_location;
    protected String lesson_type;
    protected String status; 

    public SessionBean() {}

    // Constructor without ID (used for inserting new records)
    public SessionBean(String student_name, String branch_location, String lesson_type, String status) {
        super();
        this.student_name = student_name;
        this.branch_location = branch_location;
        this.lesson_type = lesson_type;
        this.status = status;
    }

    // Constructor with ID (used for retrieving, editing, and updating records)
    public SessionBean(int session_id, String student_name, String branch_location, String lesson_type, String status) {
        super();
        this.session_id = session_id;
        this.student_name = student_name;
        this.branch_location = branch_location;
        this.lesson_type = lesson_type;
        this.status = status;
    }

    //Generate a standard setter and getter methods for all variables
    public int getSessionId() { return session_id; }
    public void setSessionId(int session_id) { this.session_id = session_id; }

    public String getStudentName() { return student_name; }
    public void setStudentName(String student_name) { this.student_name = student_name; }

    public String getBranchLocation() { return branch_location; }
    public void setBranchLocation(String branch_location) { this.branch_location = branch_location; }

    public String getLessonType() { return lesson_type; }
    public void setLessonType(String lesson_type) { this.lesson_type = lesson_type; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status= status; }
}
