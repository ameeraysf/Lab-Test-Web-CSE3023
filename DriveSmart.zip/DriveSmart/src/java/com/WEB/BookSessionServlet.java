package com.WEB;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.DAO.SessionDAO;
import com.Model.SessionBean;

@WebServlet("/")
public class BookSessionServlet extends HttpServlet {
    private SessionDAO sessionDAO;

    public void init() {
        sessionDAO = new SessionDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) //RETRIEVE PARAMETERS
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    

    /*protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    bookSession(request, response);
                    break;
                case "/delete":
                    deleteSession(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateSession(request, response);
                    break;
                default:
                    listSessions(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void listSessions(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<SessionBean> listSession = sessionDAO.getAllSessions();
        request.setAttribute("listSession", listSession);
        RequestDispatcher dispatcher = request.getRequestDispatcher("SessionList.jsp"); //FLAG : UNSURE IF THIS FILE IS NEEDED
        dispatcher.forward(request, response); //GOES TO PAGE WHERE SESSION LIST IS DISPLAYED
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("sessionForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        SessionBean existingCar = sessionDAO.selectSession(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("sessionForm.jsp");
        request.setAttribute("session", existingSession); // EXISTING SESSION
        dispatcher.forward(request, response); //SHOWS EDITABLE LIST
    }

    private void bookSession(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String student_name = request.getParameter("student_name");
        String branch_location = request.getParameter("branch_location");
        String lesson_type = request.getParameter("lesson_type"); //THIS ONE TOO
        String status = request.getParameter("price"); //THIS ONE HAS EXTRA PARSING GET PARAMETER BECAUSE DOUBLE
        //String newCar = new Car(brand, model, cylinder, price);
        String newSession = new Session(student_name, branch_location, lesson_type , status);
        SessionDAO.bookSession(newSession);
        response.sendRedirect("list");
    }

    private void updateSession(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String student_name = request.getParameter("student_name");
        String branch_location = request.getParameter("branch_location");
        String lesson_type = request.getParameter("lesson_type");
        String status = request.getParameter("price");

        SessionBean session = new SessionBean(id, student_name, branch_location, lesson_type, status);
        sessionDAO.updateSession(session);
        response.sendRedirect("listSession");
    }

    private void deleteSession(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        sessionDAO.deleteSession(id);
        response.sendRedirect("listSession");
    }*/
}