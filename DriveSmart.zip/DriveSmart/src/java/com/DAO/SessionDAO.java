package com.DAO;
//DAO LAYER
//HANDLES RAW SQL OPERATIONS

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.Model.SessionBean; //IMPORT FROM THE MODEL LAYER

public class SessionDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/drivesmart_db"; // DONE ESTABLISH CONNECTION METHOD TO JDBC
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_SESSION_SQL = "INSERT INTO Training_Sessions (student_name, branch_location, lesson_type, status) VALUES (?, ?, ?, ?);";
    private static final String SELECT_SESSION_BY_ID = "SELECT session_id, student_name, branch_location, lesson_type, status FROM Training_Sessions WHERE session_id = ?;";
    private static final String SELECT_ALL_SESSIONS = "SELECT * FROM Training_Sessions;";
    private static final String DELETE_SESSION_SQL = "DELETE FROM Training_Sessions WHERE session_id = ?;";
    private static final String UPDATE_SESSION_SQL = "UPDATE Training_Sessions SET student_name = ?, branch_location = ?, lesson_type = ?, status = ? WHERE session_id = ?;";

    public SessionDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void bookSession(SessionBean session) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SESSION_SQL)) {
            preparedStatement.setString(1, session.getStudentName());
            preparedStatement.setString(2, session.getBranchLocation());
            preparedStatement.setString(3, session.getLessonType());
            preparedStatement.setString(4, session.getStatus());
            preparedStatement.executeUpdate();
        }
    }

    public SessionBean selectSession(int id) {  //FLAG : ID INSTEAD OF SESSION_ID
        SessionBean session = null;
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SESSION_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                String student_name = rs.getString("Student Name");
                String branch_location = rs.getString("Branch Location");
                String lesson_type = rs.getString("Lesson Type");
                String status = rs.getString("Status");
                session = new SessionBean(id, student_name, branch_location, lesson_type, status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return session;
    }
//DONE RETRIEVAL METHOD 
    public List<SessionBean> getAllSessions() { // METHOD GET ALL SESSIONS
        List<SessionBean> session = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SESSIONS);
             ResultSet rs = preparedStatement.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("Session_ID"); //FLAG : UNSURE IF IT IS WORD OR VARIABLE //FLAG : IT USES INT ID INSTEAD OF SESSION_ID
                String student_name = rs.getString("Student Name");
                String branch_location = rs.getString("Branch Location");
                String lesson_type = rs.getString("Lesson Type");
                String status = rs.getString("Status");
                session.add(new SessionBean(id, student_name, branch_location, lesson_type, status)); //FLAG : HERE USED CARS WITH AN S FOR THE BEGINNING
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return session;
    }

    public boolean deleteSession(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SESSION_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateSession(SessionBean session) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SESSION_SQL)) {
            statement.setString(1, session.getStudentName());
            statement.setString(2, session.getBranchLocation());
            statement.setString(3, session.getLessonType());
            statement.setString(4, session.getStatus());
            statement.setInt(5, session.getSessionId());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }
}