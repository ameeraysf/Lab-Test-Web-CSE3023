<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:54:04 pm
    Author     : ameera s76240
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>DriveSmart Integrated Academy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <div><a href="" class="navbar-brand">Session Booking</a></div>
            <ul class="navbar-nav">
                <li><a href="<%=request.getContextPath()%>/list" class="nav-link">Book A Session</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <div class="container col-md-5">
        <div class="card">
            <div class="card-body">
                <c:if test="${session != null}">
                    <form action="BookSessionServlet" method="post"> <!<!-- FLAG : CHANGED FROM INSERT TO FORWARD TO SERVLET -->
                </c:if>
                <c:if test="${session == null}">
                    <form action="BookSessionServlet" method="post"> <!<!-- FLAG : THIS ONE TOO -->
                </c:if>

                <h2>
                    <c:if test="${session != null}">Edit Session Entry</c:if>
                    <c:if test="${session == null}">Add New Session</c:if>
                </h2>

                <c:if test="${session != null}">
                    <input type="hidden" name="id" value="<c:out value='${session.sessionId}' />" />
                </c:if>

                <fieldset class="form-group">
                    <label>Student Name</label>
                    <input type="text" value="<c:out value='${session.student_name}' />" class="form-control" name="student_name" required="required">
                </fieldset>

                <fieldset class="form-group">
                    <label>Branch Location</label> <-<!-- FLAG : NEED UNDERSCROLL OR NOT -->
                    <input type="text" value="<c:out value='${session.branch_location}' />" class="form-control" name="branch_location" required="required">
                </fieldset>

                <fieldset class="form-group">
                    <label>Lesson Type</label>
                    <input type="text" value="<c:out value='${session.lesson_type}' />" class="form-control" name="lesson_type" required="required">
                </fieldset>

                <fieldset class="form-group">
                    <label>Status</label>
                    <input type="text" value="<c:out value='${session.status}' />" class="form-control" name="status" required="required">
                </fieldset>

                <button type="submit" class="btn btn-success">Save Record</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>