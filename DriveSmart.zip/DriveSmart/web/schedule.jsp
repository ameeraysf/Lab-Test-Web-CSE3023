<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 3:58:01 pm
    Author     : ameera s76240
--%>


<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
    <title>DriveSmart Integrated Academy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <div><a href="" class="navbar-brand">Centralized Schedule</a></div>
        </nav>
    </header>
    <br>
    <div class="row">
        <div class="container">
            <h3 class="text-center">Live Session Lists</h3>
            <hr>
            <div class="container text-left">
                <a href="<%=request.getContextPath()%>/new" class="btn btn-success">Add New Session</a>
            </div>
            <br>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Student Name</th>
                        <th>Branch Location</th>
                        <th>Lesson Type</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="session" items="${sessionList}">
                        <tr>
                            <td><c:out value="${session.SessionId}" /></td>
                            <td><c:out value="${session.StudentName}" /></td>
                            <td><c:out value="${session.BranchLocation}" /></td>
                            <td><c:out value="${session.LessonType}" /></td>
                            <td><c:out value="${session.Status}" /></td>
                            <td>
                                <a href="edit?id=<c:out value='${session.sessionId}' />" class="btn btn-sm btn-primary">Edit</a>
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="delete?id=<c:out value='${session.sessionId}' />" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>